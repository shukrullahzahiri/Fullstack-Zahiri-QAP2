const http = require('http');
const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

class MyEmitter extends EventEmitter {}
const myEmitter = new MyEmitter();

const logEvent = (msg) => {
    const date = new Date().toISOString().split('T')[0];
    const logFileName = `./logs/${date}.log`;
    fs.appendFile(logFileName, `${new Date().toISOString()} - ${msg}\n`, (err) => {
        if (err) console.error('Error writing to log file', err);
    });
};

const getWeatherData = async () => {
    return {
        main: {
            temp: 15
        },
        weather: [
            {
                description: 'Clear sky'
            }
        ]
    };
};

const getNewsData = async () => {
    return {
        articles: [
            {
                title: 'Newfoundland and Labrador News Headline 1',
                description: 'Description for news headline 1.',
                url: 'https://example.com/news1'
            },
            {
                title: 'Newfoundland and Labrador News Headline 2',
                description: 'Description for news headline 2.',
                url: 'https://example.com/news2'
            }
        ]
    };
};

const serveStaticFile = (res, filePath, contentType, responseCode = 200) => {
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('404 Not Found');
            myEmitter.emit('error', `File not found: ${filePath}`);
        } else {
            res.writeHead(responseCode, { 'Content-Type': contentType });
            res.end(data);
            myEmitter.emit('fileRead', `File read successfully: ${filePath}`);
        }
    });
};

const server = http.createServer(async (req, res) => {
    const url = req.url;

    if (url.startsWith('/public')) {
        const filePath = path.join(__dirname, url);
        serveStaticFile(res, filePath, 'text/css');
        return;
    }

    switch (url) {
        case '/':
            serveStaticFile(res, './views/index.html', 'text/html');
            break;
        case '/about':
            serveStaticFile(res, './views/about.html', 'text/html');
            break;
        case '/contact':
            serveStaticFile(res, './views/contact.html', 'text/html');
            break;
        case '/products':
            serveStaticFile(res, './views/products.html', 'text/html');
            break;
        case '/subscribe':
            serveStaticFile(res, './views/subscribe.html', 'text/html');
            break;
        case '/daily':
            serveDailyPage(res);
            break;
        default:
            res.writeHead(404, { 'Content-Type': 'text/html' });
            res.end('<h1>404 Not Found</h1>');
            myEmitter.emit('error', `Page not found: ${url}`);
    }
});

const serveDailyPage = async (res) => {
    const weatherData = await getWeatherData();
    const newsData = await getNewsData();

    fs.readFile('./views/daily.html', 'utf8', (err, data) => {
        if (err) {
            res.writeHead(500, { 'Content-Type': 'text/html' });
            res.write('<h1>Internal Server Error</h1>');
            res.end();
            myEmitter.emit('error', `File read error: ./views/daily.html`);
            return;
        }

        let dailyInfo = data.replace(
            '{{temperature}}',
            `${weatherData.main.temp}`
        ).replace(
            '{{weather}}',
            `${weatherData.weather[0].description}`
        ).replace(
            '{{news}}',
            newsData.articles.map(article => `
                <h3>${article.title}</h3>
                <p>${article.description}</p>
                <a href="${article.url}" target="_blank">Read more</a>
            `).join('')
        );

        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write(dailyInfo);
        res.end();
        myEmitter.emit('fileRead', 'Daily info served');
    });
};

myEmitter.on('fileRead', (msg) => {
    console.log(`Event: ${msg}`);
    logEvent(msg);
});

myEmitter.on('error', (msg) => {
    console.error(`Event: ${msg}`);
    logEvent(msg);
});

server.listen(3000, () => {
    console.log('Server is listening on port 3000');
});
